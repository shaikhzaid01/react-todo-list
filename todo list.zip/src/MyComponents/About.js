import React from 'react'

const About = () => {
  return (
    <div>
      This is About Component.
      <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Molestiae nobis dicta excepturi vel, commodi sed illum fuga animi iste dolorem impedit reiciendis, accusamus, amet vero minima consequuntur corrupti ab aspernatur!</p>
    </div>
  )
}

export default About
